-- MySQL dump 10.13  Distrib 5.7.20, for osx10.13 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CLIENT` (
  `idCLIENT` mediumint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(45) NOT NULL,
  `prenom` varchar(45) NOT NULL,
  `addresse` text NOT NULL,
  `tel` varchar(10) NOT NULL,
  `mail` varchar(90) NOT NULL,
  PRIMARY KEY (`idCLIENT`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES (1,'Hamdi','Yann','2 rue Vernier 06000 Nice','0622924406','hamdiyann@hotmail.com'),(2,'Bourgogne','Laurent','110 Boulevard Pasteur 06000 Nice','0622481070','bourgognelaurent@hotmail.com'),(3,'Felci','Olivia','2 rue Joseph Garnier 06000 Nice','0660102965','felci.ol@gmail.com'),(4,'Parroche','Bertrand','10 rue Cyril Besset 06000 Nice','0493201323','bertolo@free.fr'),(5,'Douesnard','Alexandra','3 rue Trachel 06300 Nice','0621345684','douesnard.al@gmail.com');
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMMANDE`
--

DROP TABLE IF EXISTS `COMMANDE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMMANDE` (
  `idCOMMANDE` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `date_co` datetime DEFAULT NULL,
  `prixCommande` decimal(8,3) NOT NULL,
  `adresse` text NOT NULL,
  `idPizzeria` smallint(5) unsigned NOT NULL,
  `idClient` mediumint(8) unsigned NOT NULL,
  `status` enum('en cours','en attente','livrée','annulée') NOT NULL,
  `transaction` varchar(45) DEFAULT NULL,
  `commandePaye` tinyint(1) unsigned DEFAULT NULL,
  `paiementEnLigne` tinyint(1) unsigned DEFAULT NULL,
  `moyenDePaiement` enum('cash','carte de crédit') DEFAULT NULL,
  `longitute` float NOT NULL,
  `lattitude` float NOT NULL,
  PRIMARY KEY (`idCOMMANDE`),
  KEY `fk_COMMANDE_PIZZERIA1_idx` (`idPizzeria`),
  KEY `fk_id_client_idx` (`idClient`),
  CONSTRAINT `fk_COMMANDE_PIZZERIA1` FOREIGN KEY (`idPizzeria`) REFERENCES `PIZZERIA` (`idPIZZERIA`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_id_client` FOREIGN KEY (`idClient`) REFERENCES `CLIENT` (`idCLIENT`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMMANDE`
--

LOCK TABLES `COMMANDE` WRITE;
/*!40000 ALTER TABLE `COMMANDE` DISABLE KEYS */;
INSERT INTO `COMMANDE` VALUES (1,'2018-01-12 11:30:00',12.500,'2 rue vernier 06000 Nice',1,1,'livrée','50590940',1,1,NULL,0,0),(2,'2018-02-03 12:00:00',22.700,'12 rue St Joseph 06300 Nice',2,2,'livrée','68983002',1,1,NULL,0,0),(3,'2018-03-02 18:00:00',12.500,'3 avenue Floralis 06200 Nice',3,3,'en cours',NULL,0,0,'carte de crédit',0,0);
/*!40000 ALTER TABLE `COMMANDE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPOSITION_COMMANDE`
--

DROP TABLE IF EXISTS `COMPOSITION_COMMANDE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMPOSITION_COMMANDE` (
  `IdCommande` mediumint(8) unsigned NOT NULL,
  `IdPizza` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`IdCommande`,`IdPizza`),
  KEY `fk_compo_commande_idx` (`IdPizza`),
  CONSTRAINT `fk_compo_commande` FOREIGN KEY (`IdPizza`) REFERENCES `PIZZAS` (`idPIZZAS`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_compositions` FOREIGN KEY (`IdCommande`) REFERENCES `COMMANDE` (`idCOMMANDE`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPOSITION_COMMANDE`
--

LOCK TABLES `COMPOSITION_COMMANDE` WRITE;
/*!40000 ALTER TABLE `COMPOSITION_COMMANDE` DISABLE KEYS */;
INSERT INTO `COMPOSITION_COMMANDE` VALUES (1,1),(2,1),(3,1),(2,2);
/*!40000 ALTER TABLE `COMPOSITION_COMMANDE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPOSITION_STOCK`
--

DROP TABLE IF EXISTS `COMPOSITION_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `COMPOSITION_STOCK` (
  `IdPizzeria` smallint(5) unsigned NOT NULL,
  `IdStock` smallint(5) unsigned NOT NULL,
  `quantiteRestante` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`IdPizzeria`,`IdStock`),
  KEY `fk_id_stock_compo_idx` (`IdStock`),
  CONSTRAINT `fk_id_stock_compo` FOREIGN KEY (`IdStock`) REFERENCES `STOCK` (`idSTOCK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_id_stock_pizzeria` FOREIGN KEY (`IdPizzeria`) REFERENCES `PIZZERIA` (`idPIZZERIA`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPOSITION_STOCK`
--

LOCK TABLES `COMPOSITION_STOCK` WRITE;
/*!40000 ALTER TABLE `COMPOSITION_STOCK` DISABLE KEYS */;
INSERT INTO `COMPOSITION_STOCK` VALUES (1,1,10),(1,2,50),(1,3,5),(1,4,8),(1,5,45),(1,6,2),(1,7,0);
/*!40000 ALTER TABLE `COMPOSITION_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMPLOYE`
--

DROP TABLE IF EXISTS `EMPLOYE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMPLOYE` (
  `idEMPLOYE` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nomEmploye` varchar(45) NOT NULL,
  `prenomEmploye` varchar(45) NOT NULL,
  `idPizzeria` smallint(5) unsigned NOT NULL,
  `fonction` varchar(45) NOT NULL,
  PRIMARY KEY (`idEMPLOYE`),
  KEY `fk_id_pizzeria_idx` (`idPizzeria`),
  CONSTRAINT `fk_id_pizzeria` FOREIGN KEY (`idPizzeria`) REFERENCES `PIZZERIA` (`idPIZZERIA`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMPLOYE`
--

LOCK TABLES `EMPLOYE` WRITE;
/*!40000 ALTER TABLE `EMPLOYE` DISABLE KEYS */;
INSERT INTO `EMPLOYE` VALUES (1,'Ducran','Christophe',1,'Livreur'),(2,'Roulin','Romain',1,'Pizzaiolo'),(3,'Doutaz','Gerard',1,'Responsable'),(4,'Khiari','Mahrez',2,'Livreur'),(5,'Prol','Jessica',2,'Pizzaiolo'),(6,'Lisle','Tom',2,'Responsable'),(7,'Dacal','Roberto',3,'Pizzaiolo'),(8,'Conde','Franck',3,'Livreur'),(9,'Gauthier','Eric',3,'Responsable');
/*!40000 ALTER TABLE `EMPLOYE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EQUIPE`
--

DROP TABLE IF EXISTS `EQUIPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EQUIPE` (
  `idEmploye` smallint(5) unsigned NOT NULL,
  `idCommande` mediumint(8) unsigned NOT NULL,
  `dateTraitement` datetime DEFAULT NULL,
  PRIMARY KEY (`idEmploye`,`idCommande`),
  KEY `fk_id_commandse_idx` (`idCommande`),
  CONSTRAINT `fk_id_commandse` FOREIGN KEY (`idCommande`) REFERENCES `COMMANDE` (`idCOMMANDE`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_id_employe_equipe` FOREIGN KEY (`idEmploye`) REFERENCES `EMPLOYE` (`idEMPLOYE`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EQUIPE`
--

LOCK TABLES `EQUIPE` WRITE;
/*!40000 ALTER TABLE `EQUIPE` DISABLE KEYS */;
INSERT INTO `EQUIPE` VALUES (1,1,'2018-01-12 12:20:00'),(2,1,'2018-01-12 12:00:00'),(4,2,'2018-02-03 13:00:00'),(5,2,'2018-02-03 12:30:00'),(7,3,'2018-03-02 18:40:00');
/*!40000 ALTER TABLE `EQUIPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MENUDISPO`
--

DROP TABLE IF EXISTS `MENUDISPO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MENUDISPO` (
  `idMENUDISPO` smallint(5) unsigned NOT NULL,
  `idDispoPizza` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`idMENUDISPO`,`idDispoPizza`),
  KEY `fk_id_pizza_menu_idx` (`idDispoPizza`),
  CONSTRAINT `fk_id_pizza_menu` FOREIGN KEY (`idDispoPizza`) REFERENCES `PIZZAS` (`idPIZZAS`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pizza_pizzeria` FOREIGN KEY (`idMENUDISPO`) REFERENCES `PIZZERIA` (`idPIZZERIA`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MENUDISPO`
--

LOCK TABLES `MENUDISPO` WRITE;
/*!40000 ALTER TABLE `MENUDISPO` DISABLE KEYS */;
INSERT INTO `MENUDISPO` VALUES (1,1),(2,1),(4,1),(1,2),(2,2),(4,2),(1,3),(2,3),(4,3),(1,4),(2,4),(3,4),(4,4);
/*!40000 ALTER TABLE `MENUDISPO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PIZZAS`
--

DROP TABLE IF EXISTS `PIZZAS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PIZZAS` (
  `idPIZZAS` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nomPizzas` varchar(30) NOT NULL,
  `prix` decimal(8,3) NOT NULL,
  PRIMARY KEY (`idPIZZAS`),
  UNIQUE KEY `ID_nom_pizza` (`nomPizzas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PIZZAS`
--

LOCK TABLES `PIZZAS` WRITE;
/*!40000 ALTER TABLE `PIZZAS` DISABLE KEYS */;
INSERT INTO `PIZZAS` VALUES (1,'Reine',12.500),(2,'Marguerite',10.200),(3,'Orientale',11.500),(4,'Hawaienne',15.000);
/*!40000 ALTER TABLE `PIZZAS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PIZZA_COMPO`
--

DROP TABLE IF EXISTS `PIZZA_COMPO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PIZZA_COMPO` (
  `idCOMPOSITIONPIZZA` smallint(5) unsigned NOT NULL,
  `idpizzass` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`idCOMPOSITIONPIZZA`,`idpizzass`),
  KEY `fk_id_pizza_composi_idx` (`idpizzass`),
  CONSTRAINT `fk_id_pizza_composi` FOREIGN KEY (`idpizzass`) REFERENCES `PIZZAS` (`idPIZZAS`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_id_stock_pi` FOREIGN KEY (`idCOMPOSITIONPIZZA`) REFERENCES `STOCK` (`idSTOCK`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PIZZA_COMPO`
--

LOCK TABLES `PIZZA_COMPO` WRITE;
/*!40000 ALTER TABLE `PIZZA_COMPO` DISABLE KEYS */;
INSERT INTO `PIZZA_COMPO` VALUES (1,1),(2,1),(3,1),(6,1),(2,2),(6,2),(2,3),(4,3),(5,3),(6,3),(1,4),(2,4),(6,4),(7,4);
/*!40000 ALTER TABLE `PIZZA_COMPO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PIZZERIA`
--

DROP TABLE IF EXISTS `PIZZERIA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PIZZERIA` (
  `idPIZZERIA` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nomPizzeria` varchar(60) NOT NULL,
  `adresse` text NOT NULL,
  `tel` varchar(10) NOT NULL,
  PRIMARY KEY (`idPIZZERIA`),
  UNIQUE KEY `ID_unique_pizzeria` (`nomPizzeria`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PIZZERIA`
--

LOCK TABLES `PIZZERIA` WRITE;
/*!40000 ALTER TABLE `PIZZERIA` DISABLE KEYS */;
INSERT INTO `PIZZERIA` VALUES (1,'chez luigi','110 Boulevard Gambetta 06000 Nice','0450841165'),(2,'Break Pizza','140 Boulevard de l\'ariane 06300 Nice','0493405645'),(3,'Chez Mario','3 rue de Pessicart 06000 Nice','0492172222'),(4,'Chez lolo','56 avenue de la Lanterne 06200 Nice','0492145634');
/*!40000 ALTER TABLE `PIZZERIA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `STOCK`
--

DROP TABLE IF EXISTS `STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `STOCK` (
  `idSTOCK` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nomAliment` varchar(50) NOT NULL,
  `nomCat` varchar(45) NOT NULL,
  PRIMARY KEY (`idSTOCK`),
  UNIQUE KEY `id_aliment` (`nomAliment`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `STOCK`
--

LOCK TABLES `STOCK` WRITE;
/*!40000 ALTER TABLE `STOCK` DISABLE KEYS */;
INSERT INTO `STOCK` VALUES (1,'Jambon Cuit','Charcuterie'),(2,'Sauce Tomate','Conserves'),(3,'Champignons','Legumes'),(4,'Poivrons','Legumes'),(5,'Merguez','Viandes'),(6,'Mozzarela','Fromages'),(7,'ananas','fruits');
/*!40000 ALTER TABLE `STOCK` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-28 14:14:28
